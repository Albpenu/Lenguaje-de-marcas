 
class Quiz {
    constructor(props){
        console.log("Hello world!");
        this.props = props;
    }
    
    abort() {
        console.log(this.props.correctchoice[0]);
    }
}